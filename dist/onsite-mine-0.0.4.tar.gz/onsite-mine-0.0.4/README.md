# INTRODUCTION

This package serves as the simulation environment for unstructured road replay testing in Onsite competitions, enabling the loading of unstructured road scenarios and interaction between the tested  algorithm and the environment.

